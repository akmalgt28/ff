<!--- CREATED BY RAFLIPEDIA

Author Alias Name: RAFLIPEDIA
Author Real Name: Arfan Rizki Ramadhan
Author URL: raflip-edia.blogspot.com (www.raflipedia.club)
Date Created: 1 September 2017 at 7:16 PM

Note: Please don't change this copyright. Appreciate me!

--->

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="description" content="Gratis buat hosting cPanel dari RAFLIPEDIA. Gabung sekarang!">
<meta name="author" content="Arfan Rizki Ramadhan">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="js/bootstrap.js"></script>
<script src="js/jquery-1.11.1.js"></script> 
<title>cPanel Creator - RAFLIPEDIA</title>
	
</head>
<body>

<style>
body {
background-image: url(img/bg.jpg); 
background-repeat: no-repeat !important;

background-attachment: fixed;

background-size: cover;

}

.container {
  
padding-right: 15px;
  
padding-left: 15px;
  
margin-right: auto;
  
margin-left: auto;
  
padding-top: 15px;
  
width:65%;

}
</style>

<br>
<br>
<div class="container">
<div class="row">


<div class="panel panel-primary">
<div class="panel-heading"><center><b><i class="fa fa-gear"></i> cPanel Creator</b></center></div>
<div class="panel-body">
  
<?php 
set_time_limit(0);
$whm_interface_path = '/usr/local/cpanel/Cpanel/Accounting.php.inc';
function getVar($name, $def = '') {
  if (isset($_REQUEST[$name]))
    return $_REQUEST[$name];
  else
    return $def;
}
?>
<?php
$host = "IP WHM ENTE"; 
$user = "USERNAME WHM ENTE"; 
$accesshash = 'KODE AKSES HASH ENTE'; 
require_once $whm_interface_path;
$accts = listpkgs($host,$user,$accesshash,1); 
?>

<?php
if(isset($_GET['iseng'])) {
?>
<?php
$tes = listaccts($host,$user,$accesshash,1);
foreach ($tes as $kpy => $lue){ 
echo "<br/>Domain: $lue[0]";
}
?>
<?php } ?>
<?php
$tes = listaccts($host,$user,$accesshash,1);
foreach ($tes as $kpy => $lue){ 
}
$giniandoank = str_replace("http://cpanel.net/","<font color=green>Aktif</font>",$kpy);
$ko = str_replace("Unauthorized copying is prohibited -->","",$giniandoank);
$root = str_replace("Access denied","<font color=red>Failed</font>",$ko);
echo "<br/>STATUS WHM: $root";
?>


<form method="post" action="?">			
  
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-globe"></i></span>
<input class="form-control" type="domain" id="domain" name="domain" placeholder="Domain atau Subdomain" required>
</span>
</div>
</div>

</br>


<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-user"></i></span>
<input class="form-control" type="text" id="username" name="username" placeholder="Nama Pengguna" required>
</span>
</div>
</div>

</br>

<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-lock"></i></span>
<input class="form-control" type="text" id="eue" name="eue" value="KATA SANDI DIACAK OTOMATIS!" readonly>
</span>
</div>
</div>

</br>


<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-bars"></i></span>
<select type="package" class="form-control" id="package" name="package">
<?php
foreach ($accts as $key => $value){ 
echo '<option> '.$key.' </option>'; 
}
?>
</select>
</span>
</div>
</div>

</br>

<center><button type="submit" name="submit" class="btn btn-warning"><i class="fa fa-user-plus"></i> Buat Akun Sekarang</button></center>

</br>

<div class="alert alert-success"><i class="fa fa-info"></i> INFORMASI AKUN AKAN DITAMPILKAN DIBAWAH INI</div>

</br>

<pre>
<?php
set_time_limit(0);
if (!isset($user_domain)) {
  $user_domain = getVar('domain');
}

// Username of the new hosting account
if (!isset($user_name)) {
  $user_name = getVar('username');
}

// Password for the new hosting account
if (!isset($user_pass)) {
  $user_pass = getVar('password');
}

// Package for the new hosting account
if (!isset($user_plan)) {
  $user_plan = getVar('package');
}

if (!file_exists($whm_interface_path)) {
  die($whm_interface_path . " does not exist. Please update program with correct path to your WHM interface file.");
}

// if parameters passed then create account
if (!empty($user_name)) {
  // load cPanel WHM interface functions
  require_once $whm_interface_path;

  // create account on the cPanel server
  $my = createacct ($host,$user,$accesshash,1,$user_domain,$user_name,$user_pass,$user_plan);
$oke = explode('|', $my);
$gembok = implode('<br/>|', $oke);


  // output result
  echo "$gembok";
}
?>
</pre>

</br>

<div class="alert alert-danger"><i class="fa fa-warning"></i> SIMPAN DATA AKUN CPANEL ANDA. AKUN INI PENTING!</div>

</br>




</div>
</form>

</body>
</html>